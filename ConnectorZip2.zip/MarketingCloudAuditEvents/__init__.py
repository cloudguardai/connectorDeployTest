import datetime
from datetime import timedelta, timezone
import logging
import json 
import requests
import hashlib
import hmac
import base64
import time
import pytz
import csv
import os
import sys
import tempfile
import re
import azure.functions as func
from urllib.error import HTTPError

customer_id = os.environ['WorkspaceID'] 
shared_key = os.environ['WorkspaceKey']
client_Id = os.environ['MarketingCloudClientID'] 
client_Secret = os.environ['MarketingCloudSecret']
marketingcloudresturi = os.environ['MarketingCloudRESTURI']
marketingcloudauthuri = os.environ['MarketingCloudAUTHURI']
log_type = 'SalesforceMarketingCloud'
logAnalyticsUri = os.environ.get('logAnalyticsUri')

if ((logAnalyticsUri in (None, '') or str(logAnalyticsUri).isspace())):    
    logAnalyticsUri = 'https://' + customer_id + '.ods.opinsights.azure.com'

pattern = r'https:\/\/([\w\-]+)\.ods\.opinsights\.azure.([a-zA-Z\.]+)$'
match = re.match(pattern,str(logAnalyticsUri))
if(not match):
    raise Exception("Salesforce Marketing Cloud: Invalid Log Analytics Uri.")

def generate_date():
    current_time = datetime.datetime.utcnow().replace(second=0, microsecond=0)
    expiry = current_time + datetime.timedelta(minutes=17) # retrieve last 5 minutes of logs
    return current_time.strftime("%Y-%m-%dT%H:%M:%SZ"), expiry.strftime("%Y-%m-%dT%H:%M:%SZ")
#test
def checkTokenExpired(tokenExpiryPath):
    try:
        if os.path.exists(tokenExpiryPath):
            with open(tokenExpiryPath) as file:
                lines = [line.rstrip() for line in file]
            if len(lines) < 1:
                return True
            else:
                current_time = generate_date()[0]       
                tokenExpiry = lines[0]
                
                if tokenExpiry > current_time:
                    logging.info("Audit Token Expiry Date: {}".format(tokenExpiry))
                    #logging.info("Token has not expired yet. Token Expiry Date: {}. Current Time: {}".format(tokenExpiry, current_time))
                    return False
                else:
                    logging.info("Token Has Expired. Token Expiry Date: {}. Current Time: {}".format(tokenExpiry, current_time))
                    return True  
        else:
            logging.info("Audit Token File Expiry does not exist, creating one...")
            return True
    except Exception as err:
            logging.error(f'Check Token Expiry Failure. Reason: {err}') 

# Take timestamp at token creation time - 1 minute off it, add this to the future to understand the time that it will expire by, recreate once expired.
def getToken(tokenPath):
    try:
        with open(tokenPath) as file:
            lines = [line.rstrip() for line in file]
        return lines[0]
    except Exception as err:
        logging.error(f'Get Token Failure. Reason: {err}')
   


def newToken(tokenPath, tokenExpiryPath):
    try:
        # create new token
        url = marketingcloudauthuri + '/v2/token'
        payload = {
            'client_id': client_Id,
            'client_secret': client_Secret,
            'grant_type': 'client_credentials'
        }
        r = requests.post(url,
            data=payload)
        token = json.loads(r.text)['access_token']
        tokenCreationTime = generate_date()[0]
        tokenExpiry = generate_date()[1]
        with open(tokenExpiryPath, 'w') as f:
            f.write(tokenExpiry)
            logging.info("Successfully written Token Expiry")
        with open(tokenPath, 'w') as f:
            f.write(token)
            logging.info("Successfully written Token")
        return token, tokenCreationTime, tokenExpiry
    except Exception as err:
        logging.error(f'Create New Token Failure. Reason: {err}')

def build_signature(customer_id, shared_key, date, content_length, method, content_type, resource):
    x_headers = 'x-ms-date:' + date
    string_to_hash = method + "\n" + str(content_length) + "\n" + content_type + "\n" + x_headers + "\n" + resource
    bytes_to_hash = bytes(string_to_hash, encoding="utf-8")
    decoded_key = base64.b64decode(shared_key)
    encoded_hash = base64.b64encode(hmac.new(decoded_key, bytes_to_hash, digestmod=hashlib.sha256).digest()).decode()
    authorization = "SharedKey {}:{}".format(customer_id,encoded_hash)
    return authorization

def post_data(customer_id, shared_key, body, log_type):
    method = 'POST'
    content_type = 'application/json'
    resource = '/api/logs'
    rfc1123date = datetime.datetime.utcnow().strftime('%a, %d %b %Y %H:%M:%S GMT')
    content_length = len(body)
    signature = build_signature(customer_id, shared_key, rfc1123date, content_length, method, content_type, resource)
    uri = logAnalyticsUri + resource + '?api-version=2016-04-01'
    headers = {
        'content-type': content_type,
        'Authorization': signature,
        'Log-Type': log_type,
        'x-ms-date': rfc1123date
    }
    try:
        response = requests.post(uri, data=body, headers=headers)
        if (response.status_code >= 200 and response.status_code <= 299):
            print('Marketing Cloud Audit Events Accepted')
        else:
            print("Response code: {}".format(response.status_code))
            response.raise_for_status()
    except HTTPError as err:
        logging.error("HTTP Error has been raised, reason: {}".format(err))

def log_date():
    current_time = datetime.datetime.utcnow().replace(second=0, microsecond=0)
    log_time = current_time - datetime.timedelta(minutes=5) # retrieve last 5 minutes of logs
    return log_time.strftime("%Y-%m-%dT%H:%M:%SZ")

def pull_logs(Token, lastModified):
    url = f'{marketingcloudresturi}/data/v1/audit/auditEvents'
    headers = {"Authorization": f"Bearer {Token}"}
    try:
        logging.info('Searching Audit Event files last modified from {}'.format(lastModified))
        r = requests.get(url, headers=headers)
    except Exception as err:
        logging.error(f'File list getting failed. Exiting program. {err}')
    if r.status_code == 200:
        files = json.loads(r.text)['items']
        print("{}".format(files))
        return files
    else:
        logging.error(f'File list getting failed. Exiting program. {r.status_code} {r.text}')
    

def main(mytimer: func.TimerRequest) -> None:
    logging.info(f'Script started')
    global token,headers,customer_id,shared_key,log_type
    try:
        tempFilePath = tempfile.gettempdir()
        tokenPath = tempFilePath + "/.audittoken"
        tokenExpiryPath = tempFilePath + "/.audittokenexpiry"
        checkResult = checkTokenExpired(tokenExpiryPath)
        if checkResult == True:
            if os.path.exists(tokenExpiryPath):
                logging.info("Removing old Audit Token files...")
                os.remove(tokenExpiryPath)
                if os.path.exists(tokenPath):
                    os.remove(tokenPath)
            
            token=newToken(tokenPath, tokenExpiryPath)
            print("CheckResult True - Audit Token: {}".format(token))
            logPeriod = log_date() # last 5 minutes of logs
            monitorWindow = datetime.datetime.strptime(logPeriod, '%Y-%m-%dT%H:%M:%SZ') # convert logperiod into readable datetime
            logs=pull_logs(token[0],monitorWindow)
            tempList = []
            for log in logs:
                #print("Sec: {}".format(log))
                for item in log.items():
                    if item[0] == "createdDate":
                        #print(type(item[1]))
                        convertedTuple = list(item)
                        timeDiff = 6 if time.daylight == 0 else 7
                        #print(timeDiff)
                        #dt = format_time(item[1], timeDiff)
                        #if datetime.datetime.strptime(item[1], '%Y-%m-%dT%H:%M:%S.%f') + timedelta(timeDiff) == True:
                        
                        # Example log:
                        # 2023-01-09 08:07:16.530000 Log Created
                        # if 2023-01-09 08:07:16.530000 >= 2023-01-09 10:13:00 -> False -> Didn't happen today
                        # if 2023-01-09 08:07:16.530000 <= 2023-01-09 10:18:00 -> True -> not executed due to false statement above

                        # Example log:
                        # 2023-01-09 10:17:16.530000 Log Created
                        # if 2023-01-09 10:17:16.530000 >= 2023-01-09 10:13:00 -> True -> Happened today
                        # if 2023-01-09 10:17:16.530000 <= 2023-01-09 10:18:00 -> True -> Happened within last execution cycle

                        if "." not in item[1]: 
                            createdDate = datetime.datetime.strptime(item[1],'%Y-%m-%dT%H:%M:%S') + timedelta(hours=timeDiff)
                            #logging.info("True: Original Local Time Date: {} UTC Converted: {}".format(item[1], createdDate))
                        else:
                            createdDate = datetime.datetime.strptime(item[1],'%Y-%m-%dT%H:%M:%S.%f') + timedelta(hours=timeDiff)
                            #logging.info("True: Original Local Time Date: {} UTC Converted: {}".format(item[1], createdDate))

                        convertedTuple[1] = createdDate
                        item = tuple(convertedTuple)
                        currentMaxTime = monitorWindow + timedelta(minutes=5)
                        #logging.info("Created Date: {} Monitor Window: {} Current max time window: {}".format(createdDate, monitorWindow, currentMaxTime))
                        if createdDate >= monitorWindow:
                            #logging.info("Log Date: {} log period: {}".format(createdDate, monitorWindow))
                            if createdDate <= currentMaxTime:
                            # data has come through in last 5 minutes that we want to capture
                                log.update({"createdDate":f"{createdDate}"})
                                tempList.append(log)
                                logging.info("Created date: {} log period: {}".format(createdDate, monitorWindow))
                            else:
                                logging.error("Audit Events Timezone is incorrect")

            if len(tempList) > 0:
                body = json.dumps(tempList)
                # logging.info("Final Audit Data list: {}".format(body))
                logging.info("Total Marketing Cloud Audit Events sent to Sentinel: {}".format(len(tempList)))
                post_data(customer_id, shared_key, body, log_type)
            else:
                logging.info("No Marketing Cloud Audit Events Discovered")
                #logging.info("Data: {}".format(items))
        elif checkResult == False:
            # token not expired, collect and submit data to sentinel
            #logging.info("Token Value: {}".format(token))

            token=getToken(tokenPath)
            print("CheckResult False - Sec Token: {}".format(token))
            logPeriod = log_date()
            monitorWindow = datetime.datetime.strptime(logPeriod, '%Y-%m-%dT%H:%M:%SZ')            
            logs=pull_logs(token, monitorWindow)
            tempList = []

            for log in logs:
                for item in log.items():
                    if item[0] == "createdDate":
                        #print(type(item[1]))
                        convertedTuple = list(item)
                        timeDiff = 6 if time.daylight == 0 else 7
                        if "." not in item[1]: 
                            createdDate = datetime.datetime.strptime(item[1],'%Y-%m-%dT%H:%M:%S') + timedelta(hours=timeDiff)
                            #logging.info("False: Original Local Time Date: {} UTC Converted: {}".format(item[1], createdDate))
                        else:
                            createdDate = datetime.datetime.strptime(item[1],'%Y-%m-%dT%H:%M:%S.%f') + timedelta(hours=timeDiff)
                            #logging.info("False: Original Local Time Date: {} UTC Converted: {}".format(item[1], createdDate))

                        convertedTuple[1] = createdDate
                        item = tuple(convertedTuple)
                        currentMaxTime = monitorWindow + timedelta(minutes=5)

                        #logging.info("Created Date: {} Monitor Window: {} Current max time window: {}".format(createdDate, monitorWindow, currentMaxTime))

                        if createdDate >= monitorWindow:
                            logging.info("Log Date: {} log period: {}".format(createdDate, monitorWindow))
                            if createdDate <= currentMaxTime:
                            # data has come through in last 5 minutes that we want to capture
                                log.update({"createdDate":f"{createdDate}"})
                                tempList.append(log)
                                logging.info("Created date: {} log period: {}".format(createdDate, monitorWindow))
                            else:
                                logging.error("Audit Timezone is incorrect")                            
            

            if len(tempList) > 0:
                body = json.dumps(tempList)
                # logging.info("Final Audit Data list: {}".format(body))
                logging.info("Total Marketing Cloud Audit Events sent to Sentinel: {}".format(len(tempList)))
                post_data(customer_id, shared_key, body, log_type)
            else:
                logging.info("No Marketing Cloud Audit Events Discovered")
                #logging.info("Data: {}".format(items))

    except Exception as err:
        logging.error(f'Sending Audit Data Failed. Reason: {err}')
    
    logging.info('MarketingCloud AuditEvents Function finished.')
    utc_timestamp = datetime.datetime.utcnow().replace(tzinfo=datetime.timezone.utc).isoformat()
    if mytimer.past_due:
        logging.info('The timer is past due!')
    logging.info('Python timer trigger function ran at %s', utc_timestamp)