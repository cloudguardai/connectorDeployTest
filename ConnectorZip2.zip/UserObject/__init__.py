import datetime
import logging
import json 
import requests
import hashlib
import hmac
import base64
import csv
import os
import sys
import tempfile
import re
import azure.functions as func
from urllib.error import HTTPError


customer_id = os.environ['WorkspaceID'] 
shared_key = os.environ['WorkspaceKey']
log_type = 'SalesforceShield'
user = os.environ['SalesforceUser']
password = os.environ['SalesforcePass']
security_token = os.environ['SalesforceSecurityToken']
consumer_key = os.environ['SalesforceConsumerKey']
consumer_secret = os.environ['SalesforceConsumerSecret']
object =  "PasswordChange"
interval = os.getenv("timeInterval","hourly")
hours_interval = 1
days_interval = 1
url = os.environ['SalesforceTokenUri']
logAnalyticsUri = os.environ.get('logAnalyticsUri')

if ((logAnalyticsUri in (None, '') or str(logAnalyticsUri).isspace())):    
    logAnalyticsUri = 'https://' + customer_id + '.ods.opinsights.azure.com'

pattern = r'https:\/\/([\w\-]+)\.ods\.opinsights\.azure.([a-zA-Z\.]+)$'
match = re.match(pattern,str(logAnalyticsUri))
if(not match):
    raise Exception("Salesforce Service Cloud: Invalid Log Analytics Uri.")

def _get_token():
    params = {
        "grant_type": "password",
        "client_id": consumer_key,
        "client_secret": consumer_secret,
        "username": user,
        "password": f'{password}{security_token}'
    }
    try:
        r = requests.post(url, params=params)
        _token = json.loads(r.text)['access_token']
        _instance_url = json.loads(r.text)['instance_url']
        return _token,_instance_url
    except Exception as err:
        logging.error(f'Token getting failed. Exiting program. {err}')
        exit()


def generate_date():
    if interval == 'hourly':
        current_time = datetime.datetime.utcnow().replace(second=0, microsecond=0)
        past_time = current_time - datetime.timedelta(days=3)
    elif interval == 'daily':
        current_time = datetime.datetime.utcnow().replace(hour=0, minute=0, second=0, microsecond=0)
        past_time = current_time - datetime.timedelta(days=days_interval, hours=1)
    return past_time.strftime("%Y-%m-%dT%H:%M:%SZ")
    

def pull_log_files():
    past_time = generate_date()
    if interval == 'hourly':
        # our custom query
        # Daily query (from the original code)
        query = "/services/data/v56.0/query?q=SELECT+FIELDS(STANDARD)" + \
                "+FROM+User"
        
    try:
        logging.info('Searching files last modified from {}'.format(past_time))
        r = requests.get(f'{instance_url}{query}', headers=headers)
    except Exception as err:
        logging.error(f'File list getting failed. Exiting program. {err}')
    if r.status_code == 200:
        files = json.loads(r.text)['records']
        done_status = json.loads(r.text)['done']
        while done_status is False:
            query = json.loads(r.text)['nextRecordsUrl']
            try:
                r = requests.get(f'{instance_url}{query}', headers=headers)
            except Exception as err:
                logging.error(f'File list getting failed. Exiting program. {err}')
            if r.status_code == 200:
                done_status = json.loads(r.text)['done']
                for file in json.loads(r.text)['records']:
                    files.append(file)
            else:
                done_status = True
        return files
        
    else:
        logging.error(f'File list getting failed. Exiting program. {r.status_code} {r.text}')


def get_users(url=None):
    if url is None:
        query = "/services/data/v44.0/query?q=SELECT+Id+,+Email+FROM+User"
    else:
        query = url
    try:
        r = requests.get(f'{instance_url}{query}', headers=headers)

        for x in r.json()['records']:
            users.update({x['Id']: x['Email']})

        if not r.json()['done']:
            next_url = r.json()['nextRecordsUrl']
            get_users(url=next_url)
    except Exception as err:
        logging.error(f'Users getting failed. {err}')

def build_signature(customer_id, shared_key, date, content_length, method, content_type, resource):
    x_headers = 'x-ms-date:' + date
    string_to_hash = method + "\n" + str(content_length) + "\n" + content_type + "\n" + x_headers + "\n" + resource
    bytes_to_hash = bytes(string_to_hash, encoding="utf-8")
    decoded_key = base64.b64decode(shared_key)
    encoded_hash = base64.b64encode(hmac.new(decoded_key, bytes_to_hash, digestmod=hashlib.sha256).digest()).decode()
    authorization = "SharedKey {}:{}".format(customer_id,encoded_hash)
    return authorization

def post_data(customer_id, shared_key, body, log_type):
    method = 'POST'
    content_type = 'application/json'
    resource = '/api/logs'
    rfc1123date = datetime.datetime.utcnow().strftime('%a, %d %b %Y %H:%M:%S GMT')
    content_length = len(body)
    signature = build_signature(customer_id, shared_key, rfc1123date, content_length, method, content_type, resource)
    uri = logAnalyticsUri + resource + '?api-version=2016-04-01'
    headers = {
        'content-type': content_type,
        'Authorization': signature,
        'Log-Type': log_type,
        'x-ms-date': rfc1123date
    }
    try:
        response = requests.post(uri, data=body, headers=headers)
        if (response.status_code >= 200 and response.status_code <= 299):
            print('User Password Events Accepted')
        else:
            print("Response code: {}".format(response.status_code))
            response.raise_for_status()
    except HTTPError as err:
        logging.error("HTTP Error has been raised, reason: {}".format(err))

def main(mytimer: func.TimerRequest) -> None:
    logging.info(f'UserObject Script started')
    global instance_url,token,headers,customer_id,shared_key,log_type,users,temp_dir
    users = dict()
    token = _get_token()[0]
    instance_url = _get_token()[1]
    headers = {
        'Authorization': f'Bearer {token}'
    }
    pullData = pull_log_files() # List containing Dictionary

    
    try:
## Challenge ##

# (1) seperate attributes values : type and url
# (2) save attributes keys and values in a temporary dictionary
# (3) re-name the keys to event_type and url
# (4) continue to loop through list of dictionaries and append the rest of the data into the dictionary
# (5) move onto next file and re-do steps 1-5 until all files have been accounted for.

        tempdict = {}
        templist = []
        for log in pullData: ## enter list to retrieve each log as a dictionary
            templog = {}
            for item in log:
                if item == "attributes":
                    values = log[f"{item}"].values()
                    #for i in test1:
                    for i in values:
                        #print(i)
                        if i == "User":
                            #print(i)
                            tempdict.update({"Account_Type": i}) ## add new parsed field into temporary dictionary
                        elif i.startswith("/services/data/v56.0/sobjects/User/"):
                            #print(i)
                            tempdict.update({"object_url": i}) ## add new parsed field into temporary dictionary
                elif item == "LastPasswordChangeDate":
                    if log[item] != None: ## only logs with a date will be visible
                        tempdict.update({"LastPasswordChangeDate": log[item]})
                    else:
                        log = {}
                        break
            if "attributes" in log:
                log.pop("attributes")    
                
            templog = log ## swap existing event data into temp log
            del log       ## delete the original log so that we can swap the event_type and url to the beginning position of the dictionary
            log = {}      ## reinitialise the variable as a dict so it can be addressed
            for new_s, new_val in tempdict.items(): ## parse the event type and url first into the dictionary
                log.update({new_s: new_val})
            log.update({"attribute_type":"LastPasswordChangeDate"})
            
            for new_s, new_val in templog.items():  ## rebuild the main dictionary with temp data
                log.update({new_s: new_val})

            templist.append(log) ## append each log in its reformatted structure back into a list
            #logging.info("{}".format(log))
        ## end of file ##
        for item in templist:
            if "LastPasswordChangeDate" in item:
                next
            else:
                templist.remove(item)

        templist.pop(0)

        body = json.dumps(templist)
        logcount = len(templist)
        if logcount > 0:
            logging.info('Total number of Password Events is {}.'.format(logcount))
            logging.info("{}".format(body))
            post_data(customer_id, shared_key, body, log_type)
        else:
            print("No PasswordChange Events Discovered")

    except Exception as err:
        logging.error(f'Sending Data Failed. Reason: {err}')

    logging.info('Program finished.')
    utc_timestamp = datetime.datetime.utcnow().replace(tzinfo=datetime.timezone.utc).isoformat()
    if mytimer.past_due:
        logging.info('The timer is past due!')
    logging.info('Python timer trigger function ran at %s', utc_timestamp)